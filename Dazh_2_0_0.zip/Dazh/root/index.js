//const mysql = require("mysql")
const fs = require("fs")
const http = require("http")
const prompt = require("prompt-sync")({ sigint : true })
//const { execSync } = require("child_process")
//const title = require("console-title")
//const ls = require("local-storage")

const OS = {
    version : "2.0.0",
    user : "",
    note : {},
    variables : {},
    packages : {},
    lpackages : {},
    enable_packages : {
        "pro" : false,
        //"if" : false,
        //"fls" : false,
        "trf" : false,
    },
    installed_packages : [
        "pro",
        //"if",
        "fls",
    ],
    alpha : false,
    //r : "\\x1b[31m",
    //g : "\\x1b[32m",
    //b : "\\x1b[34m",
    //n : "\\x1b[0m",

    lcode (real, count, max) {
        const input = prompt("! cod >")
        //console.log(real[count])
        if (input == "[exit]") {
            //console.log(real)
            if (real[count + 1] != undefined) {
                this.lrun(real, count + 1, max)
            } else {
                if (process.argv[2] != "os" && process.argv[2] != undefined) {
                    return
                } else {
                    this.main()
                }
            }
        } else {
            if (this.note["lcode"] != undefined) {
                this.note["lcode"] = this.note["lcode"] + input + "\n"
            } else {
                this.note["lcode"] = "" + input + "\n"
                //console.log(this.note["lcode"])
            }
            this.lcode(real, count, max)
        }
    },

    lrun (real, count, max) {
        //const max = real.length
        for (let lcount = 0; lcount < max; lcount++) {
            //console.log(real[count + 1])
            /**
             * if (real[count] == "?") {
                //count += 1
                //bound()
            } else
             */
            if (real[count] == "til" && real[count + 1]) {
                //console.log("e")
                //title(count + 1)
                process.title = real[count + 1]
                process.stdout.write(
                    "\x1b]2;" + real[count + 1] + "\x1b\x5c"
                )
                /*if (process.platform == "win32") {
                    process.title = real[count + 1]
                } else {
                    process.stdout.write(
                        "\x1b]2;" + real[count + 1] + "\x1b\x5c"
                    )
                }*/
                //count += 1
                //bound()
            }
            if (real[count] == "?") {}
            if (real[count] == "dev" && real[count + 1] && real[count + 2] && real[count + 3]) {
                if (real[count + 3] != "pro") {
                    this.variables[real[count + 1]] = real[count + 3]
                } else {
                    if (this.enable_packages.pro == true) {
                        if (real[count + 4] != "und") {
                            const pro = prompt(real[count + 4])
                            this.variables[real[count + 1]] = pro
                            count += 4
                        }
                        if (real[count + 4] == "und") {
                            const pro = prompt()
                            this.variables[real[count + 1]] = pro
                            count += 4
                        }
                    }
                }
                //count += 1
                //bound()
            }
            if (real[count] == "wit" && real[count + 1] && real[count + 2]) {
                const time = parseInt(real[count + 1]) * 1000
                //console.log(time)
                console.log("DEPRECATED : " + real[count])
                if (real[count + 3] != "und") {
                    setTimeout( function () {
                        OS.run_once(real[count + 2] + " " + real[count + 3])
                    }, time)
                }
                if (real[count + 3] == "und") {
                    setTimeout( function () {
                        OS.run_once(real[count + 2])
                    }, time)
                }
                /*setTimeout( function () {
                    if (real[count + 3] != "und") {
                        OS.run_once(real[count + 2] + " " + real[count + 3])
                    }
                    if (real[count + 3] == "und") {
                        OS.run_once(real[count + 2])
                    }
                }, time)*/
                /*setTimeout(function () {
                    if (real[count + 3] != "und") {
                        OS.run_once(real[count + 2] + " " + real[count + 3])
                    }
                    if (real[count + 3] == "und") {
                        OS.run_once(real[count + 2])
                    }
                }, time);*/
            }
            /*if (real[count] == "prt" && real[count + 1]) {
                if (this.variables[real[count + 1]]) {
                    try {
                        console.log(this.variables[real[count + 1]])
                    } catch (error) {
                        console.log(error)
                    }
                } else {
                    console.log(real[count + 1])
                } 
                //count += 1
            }*/
            if (real[count] == "prt" && real[count + 1]) {
                if (this.variables[real[count + 1]]) {
                    try {
                        const white_spaced = this.variables[real[count + 1]].split("_").toString()
                        console.log(white_spaced)
                    } catch (error) {
                        console.log(error)
                    }
                } else {
                    const white_spaced = real[count + 1].split("_").toString()
                    console.log(white_spaced)
                }
            }
            if (real[count] == "sav") {
                const note = prompt("! fil >")
                if (this.note["lcur"] != null) {
                    this.note["lcur"] = this.note["lcur"]+"\n"+note
                } else {
                    this.note["lcur"] = ""+"\n"+note
                }
            }
            if (real[count] == "lod") {
                console.log(this.note["lcur"])
            }
            if (real[count] == "cre" && real[count + 1]) {
                if (!real[count + 1].includes(".")) {
                    fs.writeFileSync(real[count + 1]+".txt",this.note["lcur"])
                }
                if (real[count + 1].includes(".")) {
                    const fix = real[count + 1].replace("\\r","")
                    const fixed = fix.toString().replace("\n","")
                    //console.log(fixed)
                    fs.appendFileSync(fixed,this.note["lcode"])
                }
                console.log("File created")
            }
            if (real[count] == "chk") {
                console.log("Dazh "+this.version+" "+this.user)
            }
            if (real[count] == "dat") {
                console.log(Date())
            }
            if (real[count] == "dow" && real[count + 1] && real[count + 2]) {
                const where = real[count + 1]
                const to = real[count + 2]
                const file = fs.createWriteStream(to)
                http.get(where, (response) => {
                    response.pipe(file)
                    file.on("finish", () => {
                        file.close(() => {
                            console.log("File downloaded")
                        })
                    })
                }).on("error", (error) => {
                    fs.unlink(to, () => {
                        console.log("File failed to download, "+error)
                    })
                })
            }
            if (real[count] == "cod") {
                //console.log(real + count.toString() + " max >" + max.toString())
                this.lcode(real, count, max)
            }
            if (real[count] == "crd") {
                console.log("Everything was made by Ry2110 :D")
            }
            if (real[count] == "pak" && real[count + 1]) {
                const package = real[count + 1]
                if (package == "pro") {
                    this.enable_packages.pro = true
                }
                if (package == "trf") {
                    this.enable_packages.trf = true
                }
            }
            if (real[count] == "pro") {
                if (real[count - 1] != "pak") {
                    if (this.enable_packages[real[count]] == true) {
                        prompt()
                    }
                }
            }
            if (real[count] == "trf" && this.enable_packages.trf == true && real[count + 1] && real[count + 2] && real[count + 3]) {
                //console.log(real[count + 2])
                if (real[count + 2] == "=") {
                    if (parseInt(real[count + 1]) == parseInt(real[count + 3])) {
                        console.log(true)
                    } else {
                        console.log(false)
                    }
                }
                if (real[count + 2] == ">") {
                    if (parseInt(real[count + 1]) > parseInt(real[count + 3])) {
                        console.log(true)
                    } else {
                        console.log(false)
                    }
                }
                if (real[count + 2] == "<") {
                    if (parseInt(real[count + 1]) < parseInt(real[count + 3])) {
                        console.log(true)
                    } else {
                        console.log(false)
                    }
                }
            }
            count += 1
        }
    },

    tokenize (uncatagorized) {
        return uncatagorized.split(" ")
    },

    main () {
        const syntaxes = prompt(" >")
        //console.log(syntaxes)
        const tokens = this.tokenize(syntaxes)
        this.run(tokens)
        //this.main()
    },

    code () {
        const input = prompt("! cod >")
        if (input == "[exit]") {
            this.main()
        } else {
            if (this.note["code"] != undefined) {
                this.note["code"] = this.note["code"] + input + "\n"
            } else {
                this.note["code"] = "" + input + "\n"
            }
            this.code()
        }
    },

    run (syntaxes) {
        /*if (syntaxes[0] == "usr" && syntaxes[1]) {
            console.log("DEPRECATED : " + syntaxes[0])
            this.user = syntaxes[1]
        }*/
        if (syntaxes[0] == "qrt") {
            console.log("DEPRECATED : " + syntaxes[0])
            return 1
        }
        if (syntaxes[0] == "") {
            this.main()
        }
        if (syntaxes[0] == "dev" && syntaxes[1] && syntaxes[2] == "=" && syntaxes[3]) {
            this.variables[syntaxes[1]] = syntaxes[3]
        }
        if (syntaxes[0] == "prt" && syntaxes[1]) {
            if (this.variables[syntaxes[1]]) {
                try {
                    const white_spaced = this.variables[syntaxes[1]].split("_").toString()
                    console.log(white_spaced)
                } catch (error) {
                    console.log(error)
                }
            } else {
                const white_spaced = syntaxes[1].split("_").toString()
                console.log(white_spaced)
            }
        }
        if (syntaxes[0] == "?") {}
        if (syntaxes[0] == "chk") {
            console.log("Dazh "+this.version+" "+this.user)
        }
        /*if (syntaxes[0] == "pla") {
            prompt("! ign >")
        }*/
        if (syntaxes[0] == "ext") {
            console.log("DEPRECATED : " + syntaxes[0])
            this.user = ""
        }
        if (syntaxes[0] == "sav") {
            const note = prompt("! fil >")
            if (this.note["cur"] != null) {
                this.note["cur"] = this.note["cur"]+"\n"+note
            } else {
                this.note["cur"] = ""+"\n"+note
            }
        }
        if (syntaxes[0] == "cre" && syntaxes[1]) {
            if (!syntaxes[1].includes(".")) {
                fs.writeFileSync(syntaxes[1]+".txt",this.note["cur"])
            }
            if (syntaxes[1].includes(".")) {
                const fix = syntaxes[1].replace("\\r","")
                const fixed = fix.toString().replace("\n","")
                //console.log(fixed)
                fs.appendFileSync(fixed,this.note["code"])
            }
            console.log("File created")
        }
        if (syntaxes[0] == "dat"/* && syntaxes[1] && syntaxes[2] == "=" && syntaxes[3]*/) {
            //this.note["dat"]
            console.log(Date())
        }
        if (syntaxes[0] == "dow" && syntaxes[1] && syntaxes[2]) {
            const where = syntaxes[1]
            const to = syntaxes[2]
            const file = fs.createWriteStream(to)
            http.get(where, (response) => {
                response.pipe(file)
                file.on("finish", () => {
                    file.close(() => {
                        console.log("File downloaded")
                    })
                })
            }).on("error", (error) => {
                fs.unlink(to, () => {
                    console.log("File failed to download, "+error)
                })
            })
        }
        if (syntaxes[0] == "lod") {
            console.log(this.note["cur"])
        }
        //if (syntaxes[0] == "qrt") {
        //    return
        //}
        if (syntaxes[0] == "crd") {
            console.log("Everything was made by Ry2110 :D")
        }
        if (syntaxes[0] == "cod") {
            OS.code()
        }
        if (syntaxes[0] == "til" && syntaxes[1]) {
            process.title = real[count + 1]
            process.stdout.write(
                "\x1b]2;" + real[count + 1] + "\x1b\x5c"
            )
        }
        if (syntaxes[0] == "run" && syntaxes[1]) {
            if (this.alpha == false) {
                const file = fs.readFileSync(syntaxes[1],"utf-8")
                //const tokens = file.split(" " && "," && "\n" && "\r")
                //const tokens = file.split(" " /*&& "," && "\n" && "\r"*/)
                const tokens = file
                //if (rtokens.includes("n" || "\r" || ",")) {
                //    const hold = rtokens.replace("\n", "[space]")
                //    const full = hold.replace("\r" || ",", "")
                //}
                const hold = tokens.replace("\n" || "[space]", " ")
                const full = hold.replace("\r" || ",", "")
                const real = full.split(" ")
                const max = real.length
                const count = 0
                //const file_type = real.toString().split(".")
                //console.log(real)
                this.lrun(real, count, max)
            } else {
                console.log("WIP")
            }
            //const frtokens = rtokens.split(" ")
            //const vrtokens = rtokens.toString().split(",")
            //const vrotokens = vrtokens.toString().split("\n")
            //const svrtokens = vrotokens.toString().split(",")
            //this.lrun(real)
            /*console.log(real)
            console.log(real.length)
            let count = 1
            do {
                console.log(count)
                OS.run(real[count])
                count += 1
            } while (count < real.length);*/
            /*fs.readFile(syntaxes[1],"utf-8", (err, data) => {
                if (err) {
                    console.log("Error while finding the file you provided.")
                } else {
                    let spls = data.split(" ")
                    console.log(spls)
                }
            })*/
        }
        if (syntaxes[0] == undefined) {}
        if (syntaxes[0] =="usr" && syntaxes[1]) {
            console.log("DEPRECATED : " + syntaxes[0])
            this.user = syntaxes[1]
        }
        /*if (syntaxes[0] == "pak" && syntaxes[1]) {
            const package = syntaxes[1]
            if (this.installed_packages.find(package)) {
                this.enable_packages[package] = true
            }
        }*/
        //else {
        //    console.log(syntaxes[0] + " isn't in Dazh commands.")
        //}
        //if (syntaxes[0] == "da")
        /*if (syntaxes[0] == "fmk" && syntaxes[1] == "pxl" && syntaxes[2]) {
            if (syntaxes[2] == "r") {
                console.log(this.r+"#"+this.n)
            }
            if (syntaxes[2] == "g") {
                console.log(this.g+"#"+this.n)
            }
            if (syntaxes[2] == "b") {
                console.log(this.b+"#"+this.n)
            }
        }*/
        this.main()
        //if (this.user != "" || this.user == "") {
         //   if (syntaxes[0] != "qrt") {
         //       
         //   } else {
        //        return
        //    }
        //} else {
        //    console.log("Please set your user name before enter the main code.")
        //    this.main()
        //}
    },
    run_once (syntaxes) {
        /*if (syntaxes[0] == "usr" && syntaxes[1]) {
            console.log("DEPRECATED : " + syntaxes[0])
            this.user = syntaxes[1]
        }*/
        if (syntaxes[0] == "qrt") {
            console.log("DEPRECATED : " + syntaxes[0])
            return 1
        }
        if (syntaxes[0] == "") {
            this.main()
        }
        if (syntaxes[0] == "dev" && syntaxes[1] && syntaxes[2] == "=" && syntaxes[3]) {
            this.variables[syntaxes[1]] = syntaxes[3]
        }
        if (syntaxes[0] == "prt" && syntaxes[1]) {
            if (this.variables[syntaxes[1]]) {
                try {
                    console.log(this.variables[syntaxes[1]])
                } catch (error) {
                    console.log(error)
                }
            } else {
                console.log(syntaxes[1])
            }
        }
        if (syntaxes[0] == "?") {}
        if (syntaxes[0] == "chk") {
            console.log("Dazh "+this.version+" "+this.user)
        }
        /*if (syntaxes[0] == "pla") {
            prompt("! ign >")
        }*/
        if (syntaxes[0] == "ext") {
            console.log("DEPRECATED : " + syntaxes[0])
            this.user = ""
        }
        if (syntaxes[0] == "sav") {
            const note = prompt("! fil >")
            if (this.note["cur"] != null) {
                this.note["cur"] = this.note["cur"]+"\n"+note
            } else {
                this.note["cur"] = ""+"\n"+note
            }
        }
        if (syntaxes[0] == "cre" && syntaxes[1]) {
            if (!syntaxes[1].includes(".")) {
                fs.writeFileSync(syntaxes[1]+".txt",this.note["cur"])
            }
            if (syntaxes[1].includes(".")) {
                const fix = syntaxes[1].replace("\\r","")
                const fixed = fix.toString().replace("\n","")
                //console.log(fixed)
                fs.appendFileSync(fixed,this.note["code"])
            }
            console.log("File created")
        }
        if (syntaxes[0] == "dat"/* && syntaxes[1] && syntaxes[2] == "=" && syntaxes[3]*/) {
            //this.note["dat"]
            console.log(Date())
        }
        if (syntaxes[0] == "dow" && syntaxes[1] && syntaxes[2]) {
            const where = syntaxes[1]
            const to = syntaxes[2]
            const file = fs.createWriteStream(to)
            http.get(where, (response) => {
                response.pipe(file)
                file.on("finish", () => {
                    file.close(() => {
                        console.log("File downloaded")
                    })
                })
            }).on("error", (error) => {
                fs.unlink(to, () => {
                    console.log("File failed to download, "+error)
                })
            })
        }
        if (syntaxes[0] == "lod") {
            console.log(this.note["cur"])
        }
        //if (syntaxes[0] == "qrt") {
        //    return
        //}
        if (syntaxes[0] == "crd") {
            console.log("Everything was made by Ry2110 :D")
        }
        if (syntaxes[0] == "cod") {
            OS.code()
        }
        if (syntaxes[0] == "til" && syntaxes[1]) {
            process.title = syntaxes[1]
            process.stdout.write(
                "\x1b]2;" + syntaxes[1] + "\x1b\x5c"
            )
        }
        if (syntaxes[0] == "run" && syntaxes[1]) {
            if (this.alpha == false) {
                const file = fs.readFileSync(syntaxes[1],"utf-8")
                //const tokens = file.split(" " && "," && "\n" && "\r")
                //const tokens = file.split(" " /*&& "," && "\n" && "\r"*/)
                const tokens = file
                //if (rtokens.includes("n" || "\r" || ",")) {
                //    const hold = rtokens.replace("\n", "[space]")
                //    const full = hold.replace("\r" || ",", "")
                //}
                const hold = tokens.replace("\n" || "[space]", " ")
                const full = hold.replace("\r" || ",", "")
                const real = full.split(" ")
                const max = real.length
                const count = 0
                //const file_type = real.toString().split(".")
                //console.log(real)
                this.lrun(real, count, max)
            } else {
                console.log("WIP")
            }
            //const frtokens = rtokens.split(" ")
            //const vrtokens = rtokens.toString().split(",")
            //const vrotokens = vrtokens.toString().split("\n")
            //const svrtokens = vrotokens.toString().split(",")
            //this.lrun(real)
            /*console.log(real)
            console.log(real.length)
            let count = 1
            do {
                console.log(count)
                OS.run(real[count])
                count += 1
            } while (count < real.length);*/
            /*fs.readFile(syntaxes[1],"utf-8", (err, data) => {
                if (err) {
                    console.log("Error while finding the file you provided.")
                } else {
                    let spls = data.split(" ")
                    console.log(spls)
                }
            })*/
        }
        if (syntaxes[0] == undefined) {}
        if (syntaxes[0] =="usr" && syntaxes[1]) {
            console.log("DEPRECATED : " + syntaxes[0])
            this.user = syntaxes[1]
        }
        if (syntaxes[0] == "pak" && syntaxes[1]) {
            const package = syntaxes[1]
            if (this.installed_packages.find(package)) {
                this.enable_packages[package] = true
            }
        }
    }
}

//const binded = OS.run.bind(OS)

function Dazh(syntaxes) {
    OS.run_once(OS.tokenize(syntaxes))
}

function SYS() {
    console.log("Dazh ("+OS.version+")")
    OS.main()
}
/*OS.run(OS.tokenize("usr ry2110"))
OS.run(OS.tokenize("dev el = 1"))
OS.run(OS.tokenize("prt el"))
OS.run(OS.tokenize("chk"))*/

//console.log("Dazh ("+OS.version+")")
Dazh("til Dazh")
//console.log("-------\n|      >\n|     /")
//console.log(process.argv[2])

if (process.argv[2] == "os") {
    SYS()
}
if (process.argv[2] != "os" && process.argv[2] != undefined) {
    Dazh("run " + process.argv[2])
}
if (process.argv[2] == null) {
    console.log("The argument is empty, try using cmd ' dazh os ' or ' dazh file.dz ' ")
}
//OS.main()