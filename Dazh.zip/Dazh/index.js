//const mysql = require("mysql")
const fs = require("fs")
const http = require("http")
const prompt = require("prompt-sync")({ sigint : true })
//const title = require("console-title")
//const ls = require("local-storage")

const OS = {
    version : "1.0.0",
    user : "",
    note : {},
    variables : {},
    alpha : false,
    //r : "\\x1b[31m",
    //g : "\\x1b[32m",
    //b : "\\x1b[34m",
    //n : "\\x1b[0m",
    lrun (real, count, max) {
        //const max = real.length
        for (let lcount = 0; lcount < max; lcount++) {
            //console.log(real[count + 1])
            /**
             * if (real[count] == "?") {
                //count += 1
                //bound()
            } else
             */
            if (real[count] == "til" && real[count + 1]) {
                //console.log("e")
                //title(count + 1)
                process.title = real[count + 1]
                process.stdout.write(
                    "\x1b]2;" + real[count + 1] + "\x1b\x5c"
                )
                /*if (process.platform == "win32") {
                    process.title = real[count + 1]
                } else {
                    process.stdout.write(
                        "\x1b]2;" + real[count + 1] + "\x1b\x5c"
                    )
                }*/
                //count += 1
                //bound()
            }
            if (real[count] == "dev" && real[count + 1] && real[count + 2] && real[count + 3]) {
                this.variables[real[count + 1]] = real[count + 3]
                //count += 1
                //bound()
            }
            if (real[count] == "prt" && real[count + 1]) {
                if (this.variables[real[count + 1]]) {
                    try {
                        console.log(this.variables[real[count + 1]])
                    } catch (error) {
                        console.log(error)
                    }
                } else {
                    console.log(real[count + 1])
                }
                //count += 1
            }
            if (real[count] == "sav") {
                const note = prompt("! fil >")
                if (this.note["cur"] != null) {
                    this.note["cur"] = this.note["cur"]+"\n"+note
                } else {
                    this.note["cur"] = ""+"\n"+note
                }
            }
            if (real[count] == "chk") {
                console.log("Dazh "+this.version+" "+this.user)
            }
            if (real[count] == "dat") {
                console.log(Date())
            }
            if (real[count] == "dow" && real[count + 1] && real[count + 2]) {
                const where = real[count + 1]
                const to = real[count + 2]
                const file = fs.createWriteStream(to)
                http.get(where, (response) => {
                    response.pipe(file)
                    file.on("finish", () => {
                        file.close(() => {
                            console.log("File downloaded")
                        })
                    })
                }).on("error", (error) => {
                    fs.unlink(to, () => {
                        console.log("File failed to download, "+error)
                    })
                })
            }
            if (real[count] == "cod") {
                const input = prompt("! cod >")
                if (input == "[exit]") {
                    this.note["code"] = input+"\n"
                } else {
                    this.code()
                }
            }
            if (real[count] == "crd") {
                console.log("Everything was made by Ry2110 :D")
            }
            count += 1
        }
    },

    tokenize (uncatagorized) {
        return uncatagorized.split(" ")
    },

    main () {
        const syntaxes = prompt(" >")
        //console.log(syntaxes)
        const tokens = this.tokenize(syntaxes)
        this.run(tokens)
        //this.main()
    },

    code () {
        const input = prompt("! cod >")
        if (input == "[exit]") {
            this.note["code"] = input+"\n"
            this.main()
        } else {
            this.code()
        }
    },

    run (syntaxes) {
        if (syntaxes[0] == "usr" && syntaxes[1]) {
            this.user = syntaxes[1]
        }
        if (syntaxes[0] == "qrt") {
            return
        }
        if (syntaxes[0] == "") {
            this.main()
        }
        if (this.user != "") {
            if (syntaxes[0] != "qrt") {
                if (syntaxes[0] == "dev" && syntaxes[1] && syntaxes[2] == "=" && syntaxes[3]) {
                    this.variables[syntaxes[1]] = syntaxes[3]
                }
                if (syntaxes[0] == "prt" && syntaxes[1]) {
                    if (this.variables[syntaxes[1]]) {
                        try {
                            console.log(this.variables[syntaxes[1]])
                        } catch (error) {
                            console.log(error)
                        }
                    } else {
                        console.log(syntaxes[1])
                    }
                }
                if (syntaxes[0] == "chk") {
                    console.log("Dazh "+this.version+" "+this.user)
                }
                /*if (syntaxes[0] == "pla") {
                    prompt("! ign >")
                }*/
                if (syntaxes[0] == "ext") {
                    this.user = ""
                }
                if (syntaxes[0] == "sav") {
                    const note = prompt("! fil >")
                    if (this.note["cur"] != null) {
                        this.note["cur"] = this.note["cur"]+"\n"+note
                    } else {
                        this.note["cur"] = ""+"\n"+note
                    }
                }
                if (syntaxes[0] == "cre" && syntaxes[1]) {
                    if (syntaxes[1] == this.note["cur"]) {
                        fs.writeFileSync(syntaxes[1]+".txt",this.note["cur"])
                    }
                    if (syntaxes[1] == this.note["code"]) {
                        fs.writeFileSync(syntaxes[1],this.note["node"])
                    }
                    console.log("File created")
                }
                if (syntaxes[0] == "dat"/* && syntaxes[1] && syntaxes[2] == "=" && syntaxes[3]*/) {
                    //this.note["dat"]
                    console.log(Date())
                }
                if (syntaxes[0] == "dow" && syntaxes[1] && syntaxes[2]) {
                    const where = syntaxes[1]
                    const to = syntaxes[2]
                    const file = fs.createWriteStream(to)
                    http.get(where, (response) => {
                        response.pipe(file)
                        file.on("finish", () => {
                            file.close(() => {
                                console.log("File downloaded")
                            })
                        })
                    }).on("error", (error) => {
                        fs.unlink(to, () => {
                            console.log("File failed to download, "+error)
                        })
                    })
                }
                if (syntaxes[0] == "lod") {
                    console.log(this.note["cur"])
                }
                if (syntaxes[0] == "qrt") {
                    return
                }
                if (syntaxes[0] == "crd") {
                    console.log("Everything was made by Ry2110 :D")
                }
                if (syntaxes[0] == "cod") {
                    OS.code()
                }
                if (syntaxes[0] == "til" && syntaxes[1]) {
                    process.title = real[count + 1]
                    process.stdout.write(
                        "\x1b]2;" + real[count + 1] + "\x1b\x5c"
                    )
                }
                if (syntaxes[0] == "run" && syntaxes[1]) {
                    if (this.alpha == false) {
                        const file = fs.readFileSync(syntaxes[1],"utf-8")
                        //const tokens = file.split(" " && "," && "\n" && "\r")
                        //const tokens = file.split(" " /*&& "," && "\n" && "\r"*/)
                        const tokens = file
                        //if (rtokens.includes("n" || "\r" || ",")) {
                        //    const hold = rtokens.replace("\n", "[space]")
                        //    const full = hold.replace("\r" || ",", "")
                        //}
                        const hold = tokens.replace("\n", "[space]")
                        const full = hold.replace("\r" || ",", "")
                        const real = full.split("[space]")
                        const max = real.length
                        const count = 0
                        //console.log(real)
                        this.lrun(real, count, max)
                    } else {
                        console.log("WIP")
                    }
                    //const frtokens = rtokens.split(" ")
                    //const vrtokens = rtokens.toString().split(",")
                    //const vrotokens = vrtokens.toString().split("\n")
                    //const svrtokens = vrotokens.toString().split(",")
                    //this.lrun(real)
                    /*console.log(real)
                    console.log(real.length)
                    let count = 1
                    do {
                        console.log(count)
                        OS.run(real[count])
                        count += 1
                    } while (count < real.length);*/
                    /*fs.readFile(syntaxes[1],"utf-8", (err, data) => {
                        if (err) {
                            console.log("Error while finding the file you provided.")
                        } else {
                            let spls = data.split(" ")
                            console.log(spls)
                        }
                    })*/
                }
                //if (syntaxes[0] == "da")
                /*if (syntaxes[0] == "fmk" && syntaxes[1] == "pxl" && syntaxes[2]) {
                    if (syntaxes[2] == "r") {
                        console.log(this.r+"#"+this.n)
                    }
                    if (syntaxes[2] == "g") {
                        console.log(this.g+"#"+this.n)
                    }
                    if (syntaxes[2] == "b") {
                        console.log(this.b+"#"+this.n)
                    }
                }*/
                this.main()
            } else {
                return
            }
        } else {
            console.log("Please set your user name before enter the main code.")
            this.main()
        }
    },
}

//const binded = OS.run.bind(OS)

function Dazh(syntaxes) {
    OS.run(OS.tokenize(syntaxes))
}

/*OS.run(OS.tokenize("usr ry2110"))
OS.run(OS.tokenize("dev el = 1"))
OS.run(OS.tokenize("prt el"))
OS.run(OS.tokenize("chk"))*/

console.log("Dazh ("+OS.version+")")
//console.log("-------\n|      >\n|     /")

OS.main()